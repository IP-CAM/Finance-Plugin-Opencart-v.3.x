
# PHP Merchant SDK Guzzle 5

## Setup

See Divido Merchant SDK wiki for setting up using the [Guzzle 5 adapter](https://github.com/dividohq/merchant-api-pub-sdk-php/wiki/Set-up#guzzle-5-adapter)