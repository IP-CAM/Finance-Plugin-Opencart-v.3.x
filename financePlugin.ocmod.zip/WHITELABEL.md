# Whitelabel Finance Plugin

## Instructions

To whitelabel the plugin to a particular client, replace the use of the word "divido" with the handle of the company you are setting up, in the following locations:

1.
